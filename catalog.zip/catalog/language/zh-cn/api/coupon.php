<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Text
$_['text_success']     = '成功：已使用选中优惠券！';

// Error
$_['error_permission'] = '警告：您没有权限访问该API！';
$_['error_coupon']     = '错误：优惠券已失效，过期或达到它的使用限制！';
