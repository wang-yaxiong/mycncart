<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_paid_amazon']          = '在亚马逊网站支付';
$_['text_total_shipping']       = '货运';
$_['text_total_shipping_tax']   = '货运税';
$_['text_total_giftwrap']       = '礼品包装';
$_['text_total_giftwrap_tax']   = '礼品包装税';
$_['text_total_sub']            = '小计';
$_['text_tax']                  = '税费';
$_['text_total']                = '总计';
$_['text_gift_message']         = '礼物留言';
