<?php
// Text
$_['text_title'] = '支付宝 (跨境支付)';
