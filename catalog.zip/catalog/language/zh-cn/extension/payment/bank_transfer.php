<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_title']            = '银行转账';
$_['text_instruction']      = '银行转账说明';
$_['text_description']      = '请按照提供的银行账号支付货款';
$_['text_payment']          = '我们将在确认收到您的付款后进行发货。';
