<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_subject']  = '你收到 %s 网站的礼品券';
$_['text_greeting'] = '恭喜您，您收到一张价值 %s 的礼品券';
$_['text_from']     = '您收到来自 %s 的礼品券！';
$_['text_message']  = '赠言';
$_['text_redeem']   = '如何使用此礼品券？当您以下网站购物时，您可以在购物车页面输入您的礼品券号码 <b>%s</b> 抵扣相应金额，然后进行结账。';
$_['text_footer']   = '若您有任何疑问，请回复本邮件。';
