<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_subject']  = '%s - 重置密码';
$_['text_greeting'] = '此邮箱地址正在请求重置 %s 网站的密码。';
$_['text_change']   = '如是您本人操作，请点击以下链接重置密码：';
$_['text_ip']       = '请求重置密码电脑 IP 地址为：';

$_['button_reset']  = '重置密码';
