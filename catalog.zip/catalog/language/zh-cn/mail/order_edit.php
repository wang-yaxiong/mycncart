<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_subject']      = '%s - 订单更新 %s';
$_['text_order_id']     = '订单号：';
$_['text_date_added']   = '订单日期：';
$_['text_order_status'] = '订单状态已更新为：';
$_['text_comment']      = '订单留言';
$_['text_link']         = '请点击以下链接查看订单详情';
$_['text_footer']       = '如果您有任何疑问，请回复这封邮件。';
