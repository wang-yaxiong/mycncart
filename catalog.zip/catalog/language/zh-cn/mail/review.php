<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_subject']	= '%s - 商品评论';
$_['text_waiting']	= '您有一条新的商品评论正在等待审核。';
$_['text_product']	= '商品：%s';
$_['text_reviewer']	= '评论人：%s';
$_['text_rating']	= '评级：%s';
$_['text_review']	= '评论内容：';
