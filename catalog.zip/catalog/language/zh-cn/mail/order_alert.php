<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_subject']          = '%s - 订单 %s';
$_['text_received']         = '网站收到一个新订单！以下是订单详情，请及时处理。';
$_['text_order_detail']     = '订单详情';
$_['text_order_id']         = '订单编号：';
$_['text_date_added']       = '订单日期：';
$_['text_order_status']     = '订单状态：';
$_['text_products']         = '商品列表';
$_['text_product']          = '商品';
$_['text_model']            = '型号';
$_['text_quantity']         = '数量';
$_['text_price']            = '金额';
$_['text_order_total']      = '订单合计';
$_['text_total']            = '总计';
$_['text_total']            = '订单金额';
$_['text_comment']          = '订单留言';
