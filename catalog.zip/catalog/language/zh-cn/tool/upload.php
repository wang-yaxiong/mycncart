<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_upload']    = '您的文件已经成功上传！';

// Error
$_['error_filename'] = '文件名必须在 2 至 64 个字符之间！';
$_['error_filetype'] = '无效文件类型！';
$_['error_upload']   = '请选择上传文件！';
