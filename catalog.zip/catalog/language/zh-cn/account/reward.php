<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Heading
$_['heading_title']      = '我的积分';

// Column
$_['column_date_added']  = '获取日期';
$_['column_description'] = '说明';
$_['column_points']      = '积分';

// Text
$_['text_account']       = '账户';
$_['text_reward']        = '奖励积分';
$_['text_total']         = '我的积分总数为：';
$_['text_no_results']    = '您现在还没有获得过积分！';
