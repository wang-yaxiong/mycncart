<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Heading
$_['heading_title']     = '下载文件';

// Text
$_['text_account']      = '会员中心';
$_['text_downloads']    = '下载文件';
$_['text_no_results']   = '您没有可下载的文件！';

// Column
$_['column_order_id']   = '订单号';
$_['column_name']       = '名称';
$_['column_size']       = '大小';
$_['column_date_added'] = '添加时间';
