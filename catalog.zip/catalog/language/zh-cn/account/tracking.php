<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Heading
$_['heading_title']    = '推广跟踪';

// Text
$_['text_account']     = '账号';
$_['text_description'] = '要获得推广佣金，我们需要在你分享出去的链接后面加上跟踪代码。请使用以下工具生成 %s 网站的跟踪链接。';

// Entry
$_['entry_code']       = '你的跟踪码';
$_['entry_generator']  = '选择商品';
$_['entry_link']       = '跟踪链接';

// Help
$_['help_generator']  = '输入要分享的商品名称';
