<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Heading
$_['heading_title']      = '我的余额';

// Column
$_['column_date_added']  = '日期';
$_['column_description'] = '描述';
$_['column_amount']      = '合计 (%s)';

// Button
$_['button_recharge']    = '充值';

// Text
$_['text_account']       = '会员中心';
$_['text_transaction']   = '我的余额';
$_['text_total']         = '我的余额为：';
$_['text_no_results']    = '您还没有任何余额记录！';
