<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Heading
$_['heading_title']     = '系统维护';

// Text
$_['text_maintenance']  = '系统维护';
$_['text_message']      = '<h1>网站维护中... </h1><p>抱歉，我们的网站正在维护中，请稍后访问！</p>';
