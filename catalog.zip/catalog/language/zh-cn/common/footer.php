<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_information']  = '信息咨询';
$_['text_service']      = '客户服务';
$_['text_extra']        = '其他';
$_['text_contact']      = '联系我们';
$_['text_return']       = '退换服务';
$_['text_sitemap']      = '网站地图';
$_['text_manufacturer'] = '品牌专区';
$_['text_voucher']      = '礼品券';
$_['text_affiliate']    = '联盟会员';
$_['text_special']      = '特别优惠';
$_['text_account']      = '会员中心';
$_['text_order']        = '历史订单';
$_['text_wishlist']     = '收藏列表';
$_['text_newsletter']   = '订阅咨询';
$_['text_powered']      = '© Copyright 2018  红福网  ICP备案编号：京ICP备18035195号-1
					<a class="yuega" target="_blank" href="http://www.beianbeian.com/beianxinxi/b7efec88-2c96-4dd1-867b-6461cfcbffbf.html">京公网安备 ICP备案</a>';
$_['text_layer_popup_title']      = '成功';
$_['button_continue_shopping']    = '继续购物';