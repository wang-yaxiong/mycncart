<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           TL <mengwb@opencart.cn>
 * @created          2016-11-08 17:33:00
 * @modified         2016-11-08 17:33:00
 */

// Text
$_['text_weixin_qrcode'] = '微信二维码';
$_['text_telephone']     = '电话咨询';
$_['text_qq']            = 'QQ在线客服';
