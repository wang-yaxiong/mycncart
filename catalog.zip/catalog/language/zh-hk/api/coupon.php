<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Text
$_['text_success']     = '成功：已使用選中優惠券！';

// Error
$_['error_permission'] = '警告：您沒有權限訪問該API！';
$_['error_coupon']     = '錯誤：優惠券已失效，過期或達到它的使用限制！';
