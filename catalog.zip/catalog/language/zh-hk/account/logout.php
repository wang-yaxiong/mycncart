<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Heading
$_['heading_title'] = '退出賬號';

// Text
$_['text_message']  = '<p>您已成功退出了您的賬戶。</p><p>您的購物車商品已保存，您下次登錄可繼續購物！</p>';
$_['text_account']  = '賬號';
$_['text_logout']   = '退出';
