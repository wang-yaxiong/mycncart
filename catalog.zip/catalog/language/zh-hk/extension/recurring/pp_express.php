<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_title']          = 'PayPal 快速結賬';
$_['text_canceled']       = '成功：支付已取消！';

// Button
$_['button_cancel']       = '取消分期付款';

// Error
$_['error_not_cancelled'] = '錯誤：%s';
$_['error_not_found']     = '無法取消分期付款';
