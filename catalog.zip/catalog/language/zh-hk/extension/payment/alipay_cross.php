<?php
// Text
$_['text_title'] = '支付寶 (跨境支付)';
