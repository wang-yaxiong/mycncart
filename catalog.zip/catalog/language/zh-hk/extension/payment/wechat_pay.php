<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */


// Heading
$_['heading_title']              = '微信掃碼支付';

// Text
$_['text_title']                 = '微信支付';
$_['text_checkout']              = '支付';
$_['text_qrcode']                = '二維碼';
$_['text_qrcode_description']    = '請使用微信 App 掃瞄二維碼！';
