<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_captcha']  = '驗證碼';

// Entry
$_['entry_captcha'] = '請輸入驗證碼';

// Error
$_['error_captcha'] = '驗證碼輸入不正確';
