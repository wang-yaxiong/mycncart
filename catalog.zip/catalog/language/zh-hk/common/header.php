<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_home']           = '首頁';
$_['text_wishlist']       = '收藏（%s）';
$_['text_shopping_cart']  = '購物車';
$_['text_category']       = '商品分類';
$_['text_account']        = '會員中心';
$_['text_register']       = '會員註冊';
$_['text_login']          = '會員登錄';
$_['text_order']          = '我的訂單';
$_['text_transaction']    = '我的餘額';
$_['text_download']       = '文件下載';
$_['text_logout']         = '註銷退出';
$_['text_checkout']       = '結賬';
$_['text_search']         = '搜索';
$_['text_all']            = '查看所有';
