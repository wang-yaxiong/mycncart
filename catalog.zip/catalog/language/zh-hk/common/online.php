<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           TL <mengwb@opencart.cn>
 * @created          2016-11-08 17:33:00
 * @modified         2016-11-08 17:33:00
 */

// Text
$_['text_weixin_qrcode'] = '微信二維碼';
$_['text_telephone']     = '電話咨詢';
$_['text_qq']            = 'QQ在線客服';
