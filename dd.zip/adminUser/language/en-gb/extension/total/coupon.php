<?php
// Heading
$_['heading_title']    = 'Coupon';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified coupon total!';
$_['text_edit']        = 'Edit Coupon';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sort Order';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify coupon total!';